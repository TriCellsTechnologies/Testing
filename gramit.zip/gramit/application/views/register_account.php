<?php
include 'head.php';
include 'header.php';
?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Become Influencer</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Become Influencer <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
        <section class="ftco-section ftco-no-pt ftco-no-pb contact-section">
      <div class="container-wrap">
        <div class="row d-flex align-items-stretch no-gutters">
          <div style="margin: auto;" class="col-md-6 p-5 order-md-last">
            <form action="#">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Full Name" id="full_name" name="full_name">
              </div>
              <div class="form-group">
                <input type="Email" class="form-control" placeholder="Your Email" id="email" name="email">
              </div>
              <div class="form-group">
                <input type="Date" class="form-control" placeholder="Date of Birth" id="dob" name="dob">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Phone Number" id="Phone" name="Phone">
              </div>
              <div class="form-group">
                <input type="Password" class="form-control" placeholder="Password" id="Password" name="Password">
              </div>
              <div class="form-group">
                <input type="submit" value="Submit" class="btn btn-primary py-3 px-5">
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    
<?php
include 'footer.php';
include 'jquery.php';
?> 